import React from 'react';

function CandidateDashboard() {
  return (
    <div className="CandidateDashboard">
      <h1>Candidate Dashboard</h1>
      <p>Manage your profile and job applications.</p>
    </div>
  );
}

export default CandidateDashboard;
