import React from 'react';

function EmployerDashboard() {
  return (
    <div className="EmployerDashboard">
      <h1>Employer Dashboard</h1>
      <p>Manage your account and post new job openings.</p>
    </div>
  );
}

export default EmployerDashboard;
